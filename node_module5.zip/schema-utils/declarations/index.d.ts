declare const _exports: typeof import('./validate').default;
export = _exports;
