'use strict';
module.exports = {
	stdout: false,
	stderr: false
};
