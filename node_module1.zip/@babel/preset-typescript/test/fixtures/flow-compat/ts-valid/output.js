var Example;

(function (Example) {
  Example[Example["Value"] = 0] = "Value";
})(Example || (Example = {}));

foo;
