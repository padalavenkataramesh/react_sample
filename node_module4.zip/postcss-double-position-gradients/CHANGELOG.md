# Changes to PostCSS Double Position Gradients

### 1.0.0 (October 28, 2018)

- Initial version
