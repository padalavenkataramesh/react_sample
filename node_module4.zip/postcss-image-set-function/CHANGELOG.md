# Changes to PostCSS image-set() Function

### 3.0.1 (September 18, 2018)

- Updated: PostCSS Values Parser 2

### 3.0.0 (September 17, 2018)

- Updated: Support for PostCSS 7+
- Updated: Support for Node 6+

### 2.0.0 (May 7, 2018)

- Sort images by DPR and use the lowest as the default

### 1.0.0 (May 2, 2018)

- Initial version
