var os = require("os");
module.exports = os;