var path = require("path");
module.exports = path;