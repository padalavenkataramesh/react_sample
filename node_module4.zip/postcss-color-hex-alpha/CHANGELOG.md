# Changes to PostCSS Color Hex Alpha

### 5.0.3 (March 30, 2019)

- Fixed: Issue with SVG hashes being interpretted as hex colors
- Updated: `postcss` to 7.0.14 (patch)
- Updated: `postcss-values-parser` to 2.0.1 (patch)

### 5.0.2 (September 18, 2018)

- Updated: PostCSS Values Parser 2 (patch for this project)

### 5.0.1 (September 18, 2018)

- Fixed: Issue correclty calculating each channel

### 5.0.0 (September 18, 2018)

- Initial version

### 4.0.0 (September 17, 2018)

- Updated: Support for PostCSS v7+
- Updated: Support for Node v6+
- Updated: color v3+

### 3.0.0 (May 15, 2017)

- Added: compatibility with postcss v6.x
- Updated dependencies

### 2.0.0 (September 8, 2015)

- Added: compatibility with postcss v5.x
- Removed: compatiblity with postcss v4.x

### 1.3.0 (August 13, 2015)

- Added: compatibility with postcss v4.1.x
([#3](https://github.com/postcss/postcss-color-hex-alpha/pull/3))

### 1.1.0 (November 25, 2014)

- Enhanced exceptions

### 1.0.0 - (October 4, 2014)

Initial release from [postcss-color](https://github.com/postcss/postcss-color)
